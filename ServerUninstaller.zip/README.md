# WibWobPadaBoom — désinstallateur

Ce paquet ne contient aucun EXE, aucune élévation automatique et ne change pas la politique PowerShell de Windows.

1. Ouvrez **Windows PowerShell** en tant qu’administrateur.
2. Allez dans le dossier extrait, puis lancez :

```powershell
.\ServerUninstaller.cmd
```

Si Windows bloque les scripts téléchargés, ouvrez les propriétés de `code.ps1`, cochez **Débloquer**, puis relancez la commande. Ne désactivez pas Microsoft Defender.

Le programme peut supprimer le dossier du serveur, PostgreSQL 18 et .NET 8. PostgreSQL est traité avec prudence : s’il ne peut pas être arrêté ou désinstallé, ses données et ses clés registre sont conservées. Les autres éléments continuent normalement.

Avant de cocher PostgreSQL, sauvegardez toute base que vous souhaitez garder : ses données seront supprimées après une désinstallation réussie.
