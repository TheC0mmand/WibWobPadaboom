# WibWobPadaBoom — désinstallateur

Lancez `ServerUninstaller.cmd` en tant qu’administrateur.

Le programme peut supprimer le dossier du serveur, PostgreSQL 18 et .NET 8. PostgreSQL est traité avec prudence : s’il ne peut pas être arrêté ou désinstallé, ses données et ses clés registre sont conservées. Les autres éléments continuent normalement.

Avant de cocher PostgreSQL, sauvegardez toute base que vous souhaitez garder : ses données seront supprimées après une désinstallation réussie.
