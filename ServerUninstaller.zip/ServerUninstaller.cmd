@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0code.ps1"
if errorlevel 1 (
  echo.
  echo Le script doit etre lance depuis un terminal PowerShell ouvert en administrateur.
  echo Consulte README.md pour la commande manuelle.
  pause
)
endlocal
