param()

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$script:LogFile = Join-Path $env:TEMP ("WibWobServerUninstaller-{0}.log" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
$script:LogControl = $null

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    return ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Write-UninstallLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
    Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
    if ($null -ne $script:LogControl) {
        $script:LogControl.AppendText($line + [Environment]::NewLine)
        $script:LogControl.SelectionStart = $script:LogControl.TextLength
        $script:LogControl.ScrollToCaret()
        [Windows.Forms.Application]::DoEvents()
    }
}

function Invoke-NativeUninstall {
    param([string]$FilePath, [string[]]$Arguments)
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $FilePath
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.Arguments = ($Arguments | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join ' '
    $process = [Diagnostics.Process]::Start($info)
    $output = $process.StandardOutput.ReadToEnd() + $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    Write-UninstallLog "$FilePath $($Arguments -join ' ') -> code $($process.ExitCode)"
    if ($output.Trim()) { Write-UninstallLog $output.Trim() }
    return $process.ExitCode -eq 0
}

function Remove-WibWobServer {
    param([string]$InstallDirectory)
    if ([string]::IsNullOrWhiteSpace($InstallDirectory) -or -not (Test-Path -LiteralPath $InstallDirectory)) {
        Write-UninstallLog "Serveur : dossier absent, ignoré."
        return
    }
    $resolved = (Resolve-Path -LiteralPath $InstallDirectory).Path
    if ($resolved.Length -lt 8 -or $resolved -match '^[A-Za-z]:\\?$') {
        throw "Dossier serveur invalide : $resolved"
    }
    Remove-Item -LiteralPath $resolved -Recurse -Force
    Write-UninstallLog "Serveur supprimé : $resolved"
    $desktop = [Environment]::GetFolderPath('Desktop')
    $shortcut = Join-Path $desktop 'WibWobPadaBoom.lnk'
    if (Test-Path -LiteralPath $shortcut) {
        Remove-Item -LiteralPath $shortcut -Force
        Write-UninstallLog "Raccourci Bureau supprimé."
    }
}

function Remove-DotNet8 {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($null -eq $winget) {
        Write-UninstallLog ".NET 8 : winget est introuvable, ignoré."
        return
    }
    foreach ($id in @('Microsoft.DotNet.SDK.8', 'Microsoft.DotNet.Runtime.8', 'Microsoft.DotNet.AspNetCore.8')) {
        try {
            if (Invoke-NativeUninstall -FilePath $winget.Source -Arguments @('uninstall', '--id', $id, '--exact', '--silent', '--accept-source-agreements', '--disable-interactivity')) {
                Write-UninstallLog ".NET : $id supprimé."
            } else {
                Write-UninstallLog ".NET : $id non supprimé ou absent, ignoré."
            }
        } catch {
            Write-UninstallLog ".NET : $id ignoré ($($_.Exception.Message))"
        }
    }
}

function Remove-PostgreSql {
    $services = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'postgres' -or $_.DisplayName -match 'PostgreSQL' })
    foreach ($service in $services) {
        try {
            if ($service.Status -ne 'Stopped') { Stop-Service -Name $service.Name -Force -ErrorAction Stop }
            Write-UninstallLog "PostgreSQL : service arrêté ($($service.Name))."
        } catch {
            Write-UninstallLog "PostgreSQL : service impossible à arrêter ($($service.Name)); PostgreSQL est entièrement ignoré."
            return
        }
    }

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($null -eq $winget) {
        Write-UninstallLog "PostgreSQL : winget est introuvable, PostgreSQL est ignoré."
        return
    }
    if (-not (Invoke-NativeUninstall -FilePath $winget.Source -Arguments @('uninstall', '--id', 'PostgreSQL.PostgreSQL.18', '--exact', '--silent', '--accept-source-agreements', '--disable-interactivity'))) {
        Write-UninstallLog "PostgreSQL : désinstallation non confirmée; fichiers, données et clés registre conservés."
        return
    }

    Start-Sleep -Seconds 2
    $remainingServices = @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'postgres' -or $_.DisplayName -match 'PostgreSQL' })
    if ($remainingServices.Count -gt 0) {
        Write-UninstallLog "PostgreSQL : un service existe encore; nettoyage des données et clés ignoré."
        return
    }
    foreach ($path in @('C:\Program Files\PostgreSQL', (Join-Path $env:APPDATA 'postgresql'), (Join-Path $env:LOCALAPPDATA 'postgresql'), (Join-Path $env:ProgramData 'PostgreSQL'))) {
        if (Test-Path -LiteralPath $path) {
            try {
                Remove-Item -LiteralPath $path -Recurse -Force
                Write-UninstallLog "PostgreSQL : données supprimées : $path"
            } catch {
                Write-UninstallLog "PostgreSQL : données non supprimées ($path) : $($_.Exception.Message)"
            }
        }
    }
    foreach ($key in @('HKLM:\SOFTWARE\PostgreSQL', 'HKLM:\SOFTWARE\WOW6432Node\PostgreSQL')) {
        if (Test-Path -LiteralPath $key) {
            try {
                Remove-Item -LiteralPath $key -Recurse -Force
                Write-UninstallLog "PostgreSQL : clé registre supprimée : $key"
            } catch {
                Write-UninstallLog "PostgreSQL : clé registre non supprimée ($key) : $($_.Exception.Message)"
            }
        }
    }
}

$form = [Windows.Forms.Form]::new()
$form.Text = 'WibWobPadaBoom — Désinstallation complète'
$form.Size = [Drawing.Size]::new(800, 630)
$form.StartPosition = 'CenterScreen'
$form.MinimumSize = [Drawing.Size]::new(720, 560)

$title = [Windows.Forms.Label]::new()
$title.Text = 'Désinstaller WibWobPadaBoom'
$title.Font = [Drawing.Font]::new('Segoe UI', 17, [Drawing.FontStyle]::Bold)
$title.Location = [Drawing.Point]::new(22, 18)
$title.AutoSize = $true
$form.Controls.Add($title)

$warning = [Windows.Forms.Label]::new()
$warning.Text = 'Attention : la suppression PostgreSQL efface définitivement ses bases de données, ses réglages locaux et ses clés registre. Les éléments impossibles à supprimer sont simplement ignorés.'
$warning.Location = [Drawing.Point]::new(26, 58)
$warning.Size = [Drawing.Size]::new(735, 48)
$form.Controls.Add($warning)

$serverLabel = [Windows.Forms.Label]::new()
$serverLabel.Text = 'Dossier du serveur'
$serverLabel.Location = [Drawing.Point]::new(26, 122)
$serverLabel.Size = [Drawing.Size]::new(150, 24)
$form.Controls.Add($serverLabel)

$serverBox = [Windows.Forms.TextBox]::new()
$serverBox.Text = Join-Path $env:LOCALAPPDATA 'WibWob Reload'
$serverBox.Location = [Drawing.Point]::new(178, 119)
$serverBox.Size = [Drawing.Size]::new(475, 26)
$serverBox.Anchor = 'Top,Left,Right'
$form.Controls.Add($serverBox)

$browse = [Windows.Forms.Button]::new()
$browse.Text = 'Parcourir'
$browse.Location = [Drawing.Point]::new(662, 118)
$browse.Size = [Drawing.Size]::new(95, 28)
$browse.Anchor = 'Top,Right'
$browse.Add_Click({
    $picker = [Windows.Forms.FolderBrowserDialog]::new()
    if ($serverBox.Text) { $picker.SelectedPath = $serverBox.Text }
    if ($picker.ShowDialog($form) -eq 'OK') { $serverBox.Text = $picker.SelectedPath }
    $picker.Dispose()
})
$form.Controls.Add($browse)

$serverCheck = [Windows.Forms.CheckBox]::new()
$serverCheck.Text = 'Supprimer le serveur sélectionné et son raccourci Bureau'
$serverCheck.Checked = $true
$serverCheck.Location = [Drawing.Point]::new(26, 165)
$serverCheck.Size = [Drawing.Size]::new(500, 24)
$form.Controls.Add($serverCheck)

$postgresCheck = [Windows.Forms.CheckBox]::new()
$postgresCheck.Text = 'Désinstaller PostgreSQL 18, puis supprimer ses données et clés registre'
$postgresCheck.Checked = $true
$postgresCheck.Location = [Drawing.Point]::new(26, 195)
$postgresCheck.Size = [Drawing.Size]::new(620, 24)
$form.Controls.Add($postgresCheck)

$dotnetCheck = [Windows.Forms.CheckBox]::new()
$dotnetCheck.Text = 'Désinstaller .NET 8 (SDK et runtimes 8 uniquement)'
$dotnetCheck.Checked = $true
$dotnetCheck.Location = [Drawing.Point]::new(26, 225)
$dotnetCheck.Size = [Drawing.Size]::new(500, 24)
$form.Controls.Add($dotnetCheck)

$confirmCheck = [Windows.Forms.CheckBox]::new()
$confirmCheck.Text = 'Je comprends que les données PostgreSQL seront définitivement supprimées.'
$confirmCheck.Location = [Drawing.Point]::new(26, 265)
$confirmCheck.Size = [Drawing.Size]::new(680, 26)
$form.Controls.Add($confirmCheck)

$script:LogControl = [Windows.Forms.RichTextBox]::new()
$script:LogControl.Location = [Drawing.Point]::new(26, 306)
$script:LogControl.Size = [Drawing.Size]::new(731, 210)
$script:LogControl.Anchor = 'Top,Bottom,Left,Right'
$script:LogControl.ReadOnly = $true
$script:LogControl.Font = [Drawing.Font]::new('Cascadia Mono', 9)
$script:LogControl.BackColor = [Drawing.Color]::FromArgb(24,24,24)
$script:LogControl.ForeColor = [Drawing.Color]::Gainsboro
$form.Controls.Add($script:LogControl)

$status = [Windows.Forms.Label]::new()
$status.Text = "Journal : $script:LogFile"
$status.Location = [Drawing.Point]::new(26, 528)
$status.Size = [Drawing.Size]::new(530, 25)
$status.Anchor = 'Bottom,Left,Right'
$form.Controls.Add($status)

$remove = [Windows.Forms.Button]::new()
$remove.Text = 'Désinstaller'
$remove.Location = [Drawing.Point]::new(550, 550)
$remove.Size = [Drawing.Size]::new(100, 32)
$remove.Anchor = 'Bottom,Right'
$form.Controls.Add($remove)

$close = [Windows.Forms.Button]::new()
$close.Text = 'Fermer'
$close.Location = [Drawing.Point]::new(658, 550)
$close.Size = [Drawing.Size]::new(100, 32)
$close.Anchor = 'Bottom,Right'
$close.Add_Click({ $form.Close() })
$form.Controls.Add($close)

$remove.Add_Click({
    if (-not $confirmCheck.Checked) {
        [Windows.Forms.MessageBox]::Show('Coche la confirmation avant de continuer.', 'Confirmation requise', 'OK', 'Warning')
        return
    }
    if (-not (Test-Administrator)) {
        [Windows.Forms.MessageBox]::Show('Lance ServerUninstaller.cmd en tant qu’administrateur.', 'Droits administrateur requis', 'OK', 'Error')
        return
    }
    if ([Windows.Forms.MessageBox]::Show('Confirmer la désinstallation sélectionnée ? Les données PostgreSQL ne pourront pas être récupérées.', 'Dernière confirmation', 'YesNo', 'Warning') -ne 'Yes') { return }
    $remove.Enabled = $false
    try {
        if ($serverCheck.Checked) { try { Remove-WibWobServer -InstallDirectory $serverBox.Text } catch { Write-UninstallLog "Serveur ignoré : $($_.Exception.Message)" } }
        if ($postgresCheck.Checked) { try { Remove-PostgreSql } catch { Write-UninstallLog "PostgreSQL ignoré : $($_.Exception.Message)" } }
        if ($dotnetCheck.Checked) { try { Remove-DotNet8 } catch { Write-UninstallLog ".NET ignoré : $($_.Exception.Message)" } }
        [Windows.Forms.MessageBox]::Show("Opération terminée. Consulte le journal :`n$script:LogFile", 'WibWobPadaBoom', 'OK', 'Information')
    } finally {
        $remove.Enabled = $true
    }
})

Write-UninstallLog 'Désinstallateur chargé.'
[void]$form.ShowDialog()
