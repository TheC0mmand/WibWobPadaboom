﻿param(
    [switch]$DryRun,
    [switch]$SelfTest,
    [switch]$AutomatedDryRun,
    [switch]$AutomatedMigrationDryRun,
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Get-ApplicationDirectory {
    $processPath = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
    if ($processPath -and [IO.Path]::GetExtension($processPath) -ieq ".exe" -and
        [IO.Path]::GetFileName($processPath) -notmatch "powershell|pwsh") {
        return [IO.Path]::GetDirectoryName($processPath)
    }
    return $PSScriptRoot
}

$script:ApplicationDirectory = Get-ApplicationDirectory

$script:EmbeddedConfigJson = @"
{
  "ProjectMegaUrl": "https://mega.nz/file/24hBnSyA#lRIf9XDH4r-HCx5K6xyKaX3B4pIrPLoH-AAxVk_cQVs",
  "ProjectArchiveSha256": "",
  "DefaultInstallDirectory": "%LOCALAPPDATA%\\WibWob Reload",
  "DatabaseName": "wibwob",
  "PostgresPort": 5432,
  "PublicPort": 5000,
  "DotNetPackageId": "Microsoft.DotNet.SDK.8",
  "PostgresPackageId": "PostgreSQL.PostgreSQL.18",
  "JavaPackageId": "EclipseAdoptium.Temurin.21.JDK",
  "JavaInstallerUrl": "https://api.adoptium.net/v3/installer/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk",
  "AndroidStudioPackageId": "Google.AndroidStudio",
  "MegaCmdPackageId": "Mega.MEGAcmd",
  "MegaCmdInstallerUrl": "https://mega.nz/MEGAcmdSetup64.exe",
  "AndroidCommandLineToolsUrl": "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip",
  "AndroidBuildToolsVersion": "36.0.0",
  "ApktoolWrapperUrl": "https://raw.githubusercontent.com/iBotPeaches/Apktool/master/scripts/windows/apktool.bat",
  "LaunchAdminWhenFinished": true
}
"@

function Read-InstallerConfig {
    param([AllowEmptyString()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        $config = $script:EmbeddedConfigJson | ConvertFrom-Json
        $script:ConfigDescription = "configuration intégrée"
    } else {
        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
            throw "Configuration introuvable : $Path"
        }
        $config = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:ConfigDescription = $Path
    }
    foreach ($required in @("ProjectMegaUrl", "DefaultInstallDirectory", "DatabaseName", "PostgresPort", "PublicPort")) {
        if ($null -eq $config.$required -or [string]::IsNullOrWhiteSpace([string]$config.$required)) {
            throw "Clé obligatoire absente du manifeste : $required"
        }
    }
    return $config
}

$script:Config = Read-InstallerConfig -Path $ConfigPath
$script:LogFile = Join-Path $env:TEMP ("WibWobInstaller-{0}.log" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
$script:LogControl = $null
$script:ProgressBar = $null
$script:StatusLabel = $null
$script:InstallationRunning = $false
$script:CancellationRequested = $false
$script:ActiveProcess = $null

function Assert-InstallationNotCancelled {
    if ($script:CancellationRequested) {
        throw [OperationCanceledException]::new("Installation annulée par l’utilisateur.")
    }
}

function Write-InstallerLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
    Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
    if ($null -ne $script:LogControl) {
        $script:LogControl.AppendText($line + [Environment]::NewLine)
        $script:LogControl.SelectionStart = $script:LogControl.TextLength
        $script:LogControl.ScrollToCaret()
        [Windows.Forms.Application]::DoEvents()
    }
}

function Set-InstallerProgress {
    param([int]$Value, [string]$Message)
    if ($null -ne $script:ProgressBar) {
        $script:ProgressBar.Value = [Math]::Max(0, [Math]::Min(100, $Value))
    }
    if ($null -ne $script:StatusLabel) {
        $script:StatusLabel.Text = $Message
    }
    Write-InstallerLog $Message
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-LocalIPv4 {
    try {
        $route = Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction Stop |
            Sort-Object RouteMetric, InterfaceMetric |
            Select-Object -First 1
        $address = Get-NetIPAddress -InterfaceIndex $route.InterfaceIndex -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -notlike "169.254.*" } |
            Select-Object -First 1 -ExpandProperty IPAddress
        if ($address) { return $address }
    } catch {
        Write-InstallerLog "Détection réseau principale indisponible : $($_.Exception.Message)"
    }
    $fallback = [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) |
        Where-Object { $_.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and $_.IPAddressToString -notlike "169.254.*" } |
        Select-Object -First 1
    if ($fallback) { return $fallback.IPAddressToString }
    return "127.0.0.1"
}

function New-LocalPassword {
    $bytes = [byte[]]::new(24)
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $generator.GetBytes($bytes)
    } finally {
        $generator.Dispose()
    }
    return ([Convert]::ToBase64String($bytes) -replace "[^A-Za-z0-9]", "").Substring(0, 24)
}

function Expand-ConfiguredPath {
    param([string]$Path)
    return [Environment]::ExpandEnvironmentVariables($Path)
}

function Get-CommandPath {
    param([string[]]$Names)
    foreach ($name in $Names) {
        $command = Get-Command $name -ErrorAction SilentlyContinue
        if ($command) { return $command.Source }
    }
    return $null
}

function ConvertTo-NativeArgument {
    param([AllowEmptyString()][string]$Value)
    if ($null -eq $Value -or $Value.Length -eq 0) { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Invoke-External {
    param(
        [Parameter(Mandatory)][AllowNull()][AllowEmptyString()][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$WorkingDirectory,
        [hashtable]$Environment,
        [switch]$AllowFailure
    )
    if ([string]::IsNullOrWhiteSpace($FilePath)) {
        throw "Impossible de lancer une commande système : le chemin de l’exécutable est vide. Consultez l’étape précédente du journal pour identifier le prérequis manquant."
    }
    $hideNext = $false
    $displayArguments = $Arguments | ForEach-Object {
        if ($hideNext) {
            $hideNext = $false
            "***"
        } elseif ($_ -match "^(--superpassword|--password)$") {
            $hideNext = $true
            $_
        } elseif ($_ -match "--superpassword\s+") {
            '"' + ($_ -replace '(--superpassword\s+)\S+', '$1***') + '"'
        } elseif ($_ -match "\s") {
            '"' + $_ + '"'
        } else {
            $_
        }
    }
    Write-InstallerLog ("$ {0} {1}" -f $FilePath, ($displayArguments -join " "))
    if ($DryRun) {
        Write-InstallerLog "SIMULATION : commande non exécutée."
        return 0
    }
    $info = [Diagnostics.ProcessStartInfo]::new()
    $nativeArguments = (($Arguments | ForEach-Object { ConvertTo-NativeArgument ([string]$_) }) -join " ")
    $extension = [IO.Path]::GetExtension($FilePath)
    if ($extension -in @(".bat", ".cmd")) {
        $info.FileName = $env:ComSpec
        $info.Arguments = '/d /s /c ""' + $FilePath + '" ' + $nativeArguments + '"'
    } else {
        $info.FileName = $FilePath
        $info.Arguments = $nativeArguments
    }
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    if ($WorkingDirectory) { $info.WorkingDirectory = $WorkingDirectory }
    if ($Environment) {
        foreach ($key in $Environment.Keys) { $info.EnvironmentVariables[$key] = [string]$Environment[$key] }
    }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $info
    [void]$process.Start()
    $script:ActiveProcess = $process
    try {
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        while (-not $process.WaitForExit(100)) {
            [Windows.Forms.Application]::DoEvents()
            if ($script:CancellationRequested) {
                try { $process.Kill() } catch {}
                throw [OperationCanceledException]::new("Installation annulée par l’utilisateur.")
            }
        }
        $process.WaitForExit()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
    } finally {
        $script:ActiveProcess = $null
    }
    Assert-InstallationNotCancelled
    foreach ($line in ($stdout -split "\r?\n")) { if ($line) { Write-InstallerLog $line } }
    foreach ($line in ($stderr -split "\r?\n")) { if ($line) { Write-InstallerLog $line } }
    if ($process.ExitCode -ne 0 -and -not $AllowFailure) {
        throw "La commande $FilePath a échoué avec le code $($process.ExitCode)."
    }
    return $process.ExitCode
}

function Get-WingetPath {
    $winget = Get-CommandPath -Names @("winget.exe", "winget")
    if (-not $winget) {
        throw "WinGet est introuvable. Installez « App Installer » depuis Microsoft Store, puis relancez cet installateur."
    }
    return $winget
}

function Install-WingetPackage {
    param([string]$PackageId, [string[]]$OverrideArguments = @())
    $winget = Get-WingetPath
    $arguments = @(
        "install", "--id", $PackageId, "--exact", "--silent",
        "--accept-package-agreements", "--accept-source-agreements",
        "--disable-interactivity"
    )
    if ($OverrideArguments.Count -gt 0) {
        $arguments += "--override"
        $arguments += ($OverrideArguments -join " ")
    }
    Invoke-External -FilePath $winget -Arguments $arguments
}

function Save-RemoteFile {
    param([string]$Uri, [string]$Destination)
    if ($DryRun) { return }
    $curl = Get-CommandPath -Names @("curl.exe")
    if ($curl) {
        Invoke-External -FilePath $curl -Arguments @(
            "--fail", "--location", "--silent", "--show-error",
            "--output", $Destination, $Uri
        )
        return
    }
    Invoke-WebRequest -Uri $Uri -OutFile $Destination -UseBasicParsing
}

function Test-DotNet8 {
    $dotnet = Get-DotNetPath
    if (-not $dotnet) { return $false }
    if ($DryRun) { return $true }
    $output = & $dotnet --list-sdks 2>$null
    return [bool]($output | Where-Object { $_ -match "^8\." })
}

function Get-DotNetPath {
    $dotnet = Get-CommandPath -Names @("dotnet.exe", "dotnet")
    if ($dotnet) { return $dotnet }
    foreach ($candidate in @(
        "$env:ProgramFiles\dotnet\dotnet.exe",
        "${env:ProgramFiles(x86)}\dotnet\dotnet.exe",
        "$env:LOCALAPPDATA\Microsoft\dotnet\dotnet.exe"
    )) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    return $null
}

function Ensure-DotNet {
    if (Test-DotNet8) {
        $dotnet = Get-DotNetPath
        Write-InstallerLog ".NET SDK 8 déjà installé : conservation ($dotnet)."
        return $dotnet
    }
    Write-InstallerLog "Installation silencieuse de .NET SDK 8."
    Install-WingetPackage -PackageId $script:Config.DotNetPackageId
    $env:Path = @(
        [Environment]::GetEnvironmentVariable("Path", "Machine"),
        [Environment]::GetEnvironmentVariable("Path", "User")
    ) -join ";"
    $dotnet = Get-DotNetPath
    if (-not $dotnet -and -not $DryRun) {
        throw ".NET SDK 8 semble installé, mais dotnet.exe reste introuvable. Redémarrez Windows puis relancez l’installateur."
    }
    if ($DryRun -and -not $dotnet) { $dotnet = "dotnet.exe" }
    return $dotnet
}

function Get-PostgresBin {
    $roots = Get-ChildItem "C:\Program Files\PostgreSQL" -Directory -ErrorAction SilentlyContinue |
        Sort-Object { [int](($_.Name -replace "[^0-9]", "") -as [int]) } -Descending
    foreach ($root in $roots) {
        if ((Test-Path (Join-Path $root.FullName "bin\psql.exe")) -and
            (Test-Path (Join-Path $root.FullName "bin\createdb.exe"))) {
            return Join-Path $root.FullName "bin"
        }
    }
    $psql = Get-CommandPath -Names @("psql.exe", "psql")
    if ($psql) { return Split-Path $psql -Parent }
    return $null
}

function Ensure-Postgres {
    param([string]$NewPassword)
    $existing = Get-PostgresBin
    if ($existing) {
        Write-InstallerLog "PostgreSQL détecté dans $existing : aucune réinstallation et aucun changement de mot de passe."
        return @{ Bin = $existing; InstalledNow = $false }
    }
    Write-InstallerLog "PostgreSQL absent : installation silencieuse."
    $override = @(
        "--mode", "unattended",
        "--unattendedmodeui", "none",
        "--superpassword", $NewPassword,
        "--serverport", [string]$script:Config.PostgresPort
    )
    Install-WingetPackage -PackageId $script:Config.PostgresPackageId -OverrideArguments $override
    $bin = Get-PostgresBin
    if (-not $bin -and -not $DryRun) { throw "PostgreSQL a été installé mais psql.exe reste introuvable." }
    if ($DryRun -and -not $bin) { $bin = "C:\Program Files\PostgreSQL\18\bin" }
    return @{ Bin = $bin; InstalledNow = $true }
}

function Get-JavaHome {
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) { return $env:JAVA_HOME }
    $candidates = Get-ChildItem "C:\Program Files\Eclipse Adoptium" -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending
    foreach ($candidate in $candidates) {
        if (Test-Path (Join-Path $candidate.FullName "bin\java.exe")) { return $candidate.FullName }
    }
    return $null
}

function Ensure-Java {
    $javaHome = Get-JavaHome
    if ($javaHome) {
        Write-InstallerLog "Java déjà installé : $javaHome"
        return $javaHome
    }
    Write-InstallerLog "Installation silencieuse de Java JDK 21."
    try {
        Install-WingetPackage -PackageId $script:Config.JavaPackageId
    } catch {
        Assert-InstallationNotCancelled
        $javaInstallerUrl = [string]$script:Config.JavaInstallerUrl
        if ([string]::IsNullOrWhiteSpace($javaInstallerUrl)) {
            throw "Java n’a pas pu être installé via WinGet et aucune URL de secours n’est configurée. Détail : $($_.Exception.Message)"
        }
        Write-InstallerLog "WinGet est indisponible pour Java. Téléchargement direct du MSI officiel Eclipse Temurin."
        $javaMsi = Join-Path $env:TEMP "WibWob-Temurin-JDK21-x64.msi"
        Save-RemoteFile -Uri $javaInstallerUrl -Destination $javaMsi
        Assert-InstallationNotCancelled
        Invoke-External -FilePath "$env:SystemRoot\System32\msiexec.exe" -Arguments @(
            "/i", $javaMsi,
            "ADDLOCAL=FeatureMain,FeatureEnvironment,FeatureJarFileRunWith,FeatureJavaHome",
            "/quiet", "/norestart"
        )
    }
    $env:Path = @(
        [Environment]::GetEnvironmentVariable("Path", "Machine"),
        [Environment]::GetEnvironmentVariable("Path", "User")
    ) -join ";"
    $javaHome = Get-JavaHome
    if (-not $javaHome -and -not $DryRun) { throw "Java a été installé mais JAVA_HOME reste introuvable." }
    if ($DryRun -and -not $javaHome) { $javaHome = "C:\Program Files\Eclipse Adoptium\jdk-21" }
    if (-not $DryRun) {
        [Environment]::SetEnvironmentVariable("JAVA_HOME", $javaHome, "Machine")
        $env:JAVA_HOME = $javaHome
    }
    return $javaHome
}

function Test-AndroidBuildTools {
    $sdk = $env:ANDROID_SDK_ROOT
    if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA "Android\Sdk" }
    $buildRoot = Join-Path $sdk "build-tools"
    if (Test-Path $buildRoot) {
        $valid = Get-ChildItem $buildRoot -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path (Join-Path $_.FullName "zipalign.exe") } |
            Select-Object -First 1
        if ($valid) { return @{ Ready = $true; Sdk = $sdk; BuildTools = $valid.FullName } }
    }
    return @{ Ready = $false; Sdk = $sdk; BuildTools = $null }
}

function Invoke-SdkManager {
    param([string]$SdkManager, [string[]]$Packages, [string]$JavaHome)
    Write-InstallerLog "Installation Android SDK : $($Packages -join ', ')"
    if ($DryRun) { return }
    if (-not (Test-Path -LiteralPath $SdkManager -PathType Leaf)) {
        throw "sdkmanager.bat est introuvable : $SdkManager"
    }
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $SdkManager
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.Arguments = (($Packages | ForEach-Object { ConvertTo-NativeArgument ([string]$_) }) -join " ")
    $info.EnvironmentVariables["JAVA_HOME"] = $JavaHome
    $process = [Diagnostics.Process]::Start($info)
    1..100 | ForEach-Object { $process.StandardInput.WriteLine("y") }
    $process.StandardInput.Close()
    while (-not $process.HasExited) {
        while (-not $process.StandardOutput.EndOfStream) { Write-InstallerLog $process.StandardOutput.ReadLine() }
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    }
    $errorText = $process.StandardError.ReadToEnd()
    if ($errorText) { Write-InstallerLog $errorText }
    if ($process.ExitCode -ne 0) { throw "sdkmanager a échoué avec le code $($process.ExitCode)." }
}

function Ensure-AndroidTools {
    param([string]$JavaHome, [string]$TemporaryDirectory)
    $status = Test-AndroidBuildTools
    if ($status.Ready) {
        Write-InstallerLog "Android Build-Tools déjà présents : $($status.BuildTools)"
        return $status
    }
    $bootstrapper = Join-Path $script:ApplicationDirectory "AndroidToolsBootstrapper.exe"
    if (Test-Path -LiteralPath $bootstrapper -PathType Leaf) {
        Write-InstallerLog "Android Build-Tools absents : installation via l'outil natif."
        Invoke-External -FilePath $bootstrapper -Arguments @(
            "--sdk", $status.Sdk,
            "--java-home", $JavaHome,
            "--url", $script:Config.AndroidCommandLineToolsUrl,
            "--build-tools", $script:Config.AndroidBuildToolsVersion
        ) -WorkingDirectory $script:ApplicationDirectory -Environment @{ "JAVA_HOME" = $JavaHome }
        return @{
            Ready = $true
            Sdk = $status.Sdk
            BuildTools = Join-Path $status.Sdk "build-tools\$($script:Config.AndroidBuildToolsVersion)"
        }
    }

    Write-InstallerLog "Outil Android natif absent : utilisation du mode PowerShell compatible."
    Write-InstallerLog "Android Build-Tools absents : installation des outils en ligne de commande."
    $sdk = $status.Sdk
    $archive = Join-Path $TemporaryDirectory "android-commandline-tools.zip"
    $extract = Join-Path $TemporaryDirectory "android-commandline-tools"
    $sdkManagerCandidates = @(
        (Join-Path $sdk "cmdline-tools\wibwob\bin\sdkmanager.bat"),
        (Join-Path $sdk "cmdline-tools\latest\bin\sdkmanager.bat"),
        (Join-Path $sdk "cmdline-tools\bin\sdkmanager.bat")
    )
    $sdkManager = $sdkManagerCandidates | Where-Object {
        Test-Path -LiteralPath $_ -PathType Leaf
    } | Select-Object -First 1

    if (-not $sdkManager -and -not $DryRun) {
        Invoke-WebRequest -Uri $script:Config.AndroidCommandLineToolsUrl -OutFile $archive -UseBasicParsing
        Expand-Archive -LiteralPath $archive -DestinationPath $extract -Force
        $managedTools = Join-Path $sdk "cmdline-tools\wibwob"
        New-Item -ItemType Directory -Path (Split-Path $managedTools -Parent) -Force | Out-Null
        if (Test-Path -LiteralPath $managedTools) {
            try {
                [IO.Directory]::Delete($managedTools, $true)
            } catch {
                throw "Les outils Android incomplets ne peuvent pas etre remplaces : $managedTools. Fermez Android Studio puis relancez l'installateur."
            }
        }

        $sourceSdkManager = Get-ChildItem -LiteralPath $extract -Filter "sdkmanager.bat" -File -Recurse |
            Select-Object -First 1
        if (-not $sourceSdkManager) {
            throw "L'archive Android telechargee ne contient pas sdkmanager.bat."
        }
        $sourceRoot = $sourceSdkManager.Directory.Parent.FullName
        New-Item -ItemType Directory -Path $managedTools -Force | Out-Null
        # Copy rather than move: Move-Item can delete files from the downloaded
        # archive while PowerShell is still enumerating cmdline-tools on some PCs.
        Copy-Item -Path (Join-Path $sourceRoot "*") -Destination $managedTools -Recurse -Force
        [Environment]::SetEnvironmentVariable("ANDROID_SDK_ROOT", $sdk, "Machine")
        $env:ANDROID_SDK_ROOT = $sdk
        $sdkManager = Join-Path $managedTools "bin\sdkmanager.bat"
    }
    if ($DryRun -and -not $sdkManager) {
        $sdkManager = Join-Path $sdk "cmdline-tools\latest\bin\sdkmanager.bat"
    }
    Invoke-SdkManager -SdkManager $sdkManager -JavaHome $JavaHome -Packages @(
        "platform-tools",
        "build-tools;$($script:Config.AndroidBuildToolsVersion)"
    )
    return @{
        Ready = $true
        Sdk = $sdk
        BuildTools = Join-Path $sdk "build-tools\$($script:Config.AndroidBuildToolsVersion)"
    }
}

function Ensure-Apktool {
    param([string]$TemporaryDirectory)
    $existing = Get-CommandPath -Names @("apktool.bat", "apktool.cmd", "apktool")
    if ($existing) {
        Write-InstallerLog "APKTool déjà installé : $existing"
        return $existing
    }
    $target = Join-Path $env:ProgramData "WibWobTools\apktool"
    Write-InstallerLog "Installation d’APKTool dans $target"
    if ($DryRun) { return Join-Path $target "apktool.bat" }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/iBotPeaches/Apktool/releases/latest" -Headers @{ "User-Agent" = "WibWobEasyInstaller" }
    $asset = $release.assets |
        Where-Object { $_.name -match "^apktool_[0-9.]+\.jar$" } |
        Select-Object -First 1
    if (-not $asset) { throw "La dernière version d’APKTool ne contient aucun fichier JAR reconnu." }
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile (Join-Path $target "apktool.jar") -UseBasicParsing
    Invoke-WebRequest -Uri $script:Config.ApktoolWrapperUrl -OutFile (Join-Path $target "apktool.bat") -UseBasicParsing
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    if (($machinePath -split ";") -notcontains $target) {
        [Environment]::SetEnvironmentVariable("Path", ($machinePath.TrimEnd(";") + ";" + $target), "Machine")
    }
    $env:Path += ";" + $target
    return Join-Path $target "apktool.bat"
}

function Get-MegaGetPath {
    $path = Get-CommandPath -Names @("mega-get.exe", "mega-get.bat", "mega-get.cmd", "mega-get")
    if ($path) { return $path }

    $roots = @(
        "$env:LOCALAPPDATA\MEGAcmd",
        "$env:APPDATA\MEGAcmd",
        "$env:ProgramFiles\MEGAcmd",
        "${env:ProgramFiles(x86)}\MEGAcmd",
        "$env:ProgramData\MEGAcmd"
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }

    foreach ($root in $roots) {
        foreach ($name in @("mega-get.exe", "mega-get.bat", "mega-get.cmd")) {
            $candidate = Join-Path $root $name
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
        $nested = Get-ChildItem -LiteralPath $root -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -in @("mega-get.exe", "mega-get.bat", "mega-get.cmd") } |
            Select-Object -First 1
        if ($nested) { return $nested.FullName }
    }
    return $null
}

function Ensure-MegaCmd {
    $megaGet = Get-MegaGetPath
    if ($megaGet) {
        Write-InstallerLog "MEGAcmd déjà disponible."
        return $megaGet
    }
    if ($DryRun) {
        Write-InstallerLog "SIMULATION : installation de MEGAcmd ignorée."
        return "mega-get.exe"
    }
    Write-InstallerLog "Installation silencieuse de MEGAcmd."
    try {
        Install-WingetPackage -PackageId $script:Config.MegaCmdPackageId
    } catch {
        if ([string]::IsNullOrWhiteSpace([string]$script:Config.MegaCmdInstallerUrl)) {
            throw "MEGAcmd n’a pas pu être installé via WinGet. Renseignez MegaCmdInstallerUrl dans le manifeste, installez MEGAcmd manuellement, ou utilisez une URL HTTPS directe. Détail : $($_.Exception.Message)"
        }
        $setup = Join-Path $env:TEMP "MEGAcmdSetup.exe"
        Write-InstallerLog "Téléchargement du programme officiel MEGAcmd de secours."
        if (-not $DryRun) {
            Invoke-WebRequest -Uri $script:Config.MegaCmdInstallerUrl -OutFile $setup -UseBasicParsing
        }
        Invoke-External -FilePath $setup -Arguments @("/S")
    }
    $env:Path = @(
        [Environment]::GetEnvironmentVariable("Path", "Machine"),
        [Environment]::GetEnvironmentVariable("Path", "User")
    ) -join ";"
    for ($attempt = 0; $attempt -lt 20 -and -not $megaGet; $attempt++) {
        $megaGet = Get-MegaGetPath
        if (-not $megaGet) { Start-Sleep -Milliseconds 500 }
    }
    if (-not $megaGet -and -not $DryRun) {
        throw "La commande mega-get (.exe ou .bat) reste introuvable après l’installation de MEGAcmd."
    }
    if ($DryRun -and -not $megaGet) { $megaGet = "mega-get.exe" }
    return $megaGet
}

function Get-ProjectArchive {
    param([string]$SelectedArchive, [string]$TemporaryDirectory)
    if ($DryRun -and [string]::IsNullOrWhiteSpace($SelectedArchive)) {
        return Join-Path $TemporaryDirectory "WibWobReload.zip"
    }
    if ([string]::IsNullOrWhiteSpace($SelectedArchive)) {
        throw "Téléchargez le ZIP depuis MEGA, puis sélectionnez-le dans l’installateur."
    }
    $archive = [IO.Path]::GetFullPath($SelectedArchive)
    if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) {
        throw "Archive introuvable : $archive"
    }
    if ([IO.Path]::GetExtension($archive) -ine ".zip") {
        throw "Le fichier du projet doit être une archive ZIP."
    }
    Write-InstallerLog "Archive locale sélectionnée : $archive"
    if (-not $DryRun -and $script:Config.ProjectArchiveSha256) {
        $actual = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
        if ($actual -ne $script:Config.ProjectArchiveSha256) {
            throw "La somme SHA-256 de l’archive ne correspond pas au manifeste."
        }
        Write-InstallerLog "Somme SHA-256 vérifiée."
    }
    return $archive
}

function Expand-ProjectArchive {
    param([string]$Archive, [string]$Destination)
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null

    # Expand-Archive runs synchronously in the WinForms thread. A V1.1 archive
    # is large enough for Windows to mark the installer as unresponsive. tar.exe
    # is bundled with supported Windows versions and is executed through the
    # responsive external-process helper instead.
    $tar = Get-CommandPath -Names @("tar.exe", "tar")
    if ($tar) {
        $exitCode = Invoke-External -FilePath $tar -Arguments @("-xf", $Archive, "-C", $Destination) -WorkingDirectory $Destination -AllowFailure
        if ($exitCode -ne 0) {
            throw "La décompression de l’archive a échoué avec le code $exitCode."
        }
        return
    }

    Write-InstallerLog "tar.exe est introuvable : utilisation de l’extracteur PowerShell de secours."
    Expand-Archive -LiteralPath $Archive -DestinationPath $Destination -Force
}

function Find-ProjectRoot {
    param([string]$ExtractedDirectory)
    if (Test-Path (Join-Path $ExtractedDirectory "Puniemu.csproj")) { return $ExtractedDirectory }
    $project = Get-ChildItem $ExtractedDirectory -Filter "Puniemu.csproj" -File -Recurse |
        Select-Object -First 1
    if (-not $project) { throw "L’archive ne contient pas Puniemu.csproj." }
    return $project.Directory.FullName
}

function Copy-DirectoryContents {
    param([string]$Source, [string]$Destination)
    Write-InstallerLog "Copie de $Source vers $Destination"
    if ($DryRun) { return }
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null

    # Copy-Item also blocks the UI on the multi-gigabyte WWR backup. Robocopy
    # keeps the cancellation button and the log window responsive through
    # Invoke-External's message loop.
    $robocopy = Join-Path $env:SystemRoot "System32\robocopy.exe"
    if (Test-Path -LiteralPath $robocopy -PathType Leaf) {
        $exitCode = Invoke-External -FilePath $robocopy -Arguments @(
            $Source, $Destination, "/E", "/COPY:DAT", "/DCOPY:DAT",
            "/R:2", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP"
        ) -AllowFailure
        if ($exitCode -gt 7) {
            throw "La copie des fichiers du projet a échoué avec le code robocopy $exitCode."
        }
        return
    }

    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
    }
}

function Export-LegacyState {
    param([string]$OldDirectory, [string]$MigrationDirectory)
    if ([string]::IsNullOrWhiteSpace($OldDirectory)) { return }
    $old = [IO.Path]::GetFullPath($OldDirectory)
    if (-not (Test-Path -LiteralPath $old -PathType Container)) { throw "Ancien dossier introuvable : $old" }
    Write-InstallerLog "Migration depuis l’ancienne installation : $old"
    $items = @(
        "appsettings.Development.json",
        "ADMIN_CLIENT\backups",
        "CUSTOM_APK_BUILDER\wibwob-custom-test.keystore",
        "CUSTOM_APK_BUILDER\builder-settings.json",
        "CUSTOM_APK_BUILDER\server.json",
        "wwr_custom_server.apk"
    )
    foreach ($relative in $items) {
        $source = Join-Path $old $relative
        if (Test-Path -LiteralPath $source) {
            $destination = Join-Path $MigrationDirectory $relative
            Write-InstallerLog "Conservation : $relative"
            if (-not $DryRun) {
                New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
            }
        }
    }
}

function Import-LegacyState {
    param([string]$MigrationDirectory, [string]$InstallDirectory)
    if ($DryRun) {
        Write-InstallerLog "SIMULATION : restauration des fichiers migrés."
        return
    }
    if (Test-Path -LiteralPath $MigrationDirectory) {
        Copy-DirectoryContents -Source $MigrationDirectory -Destination $InstallDirectory
    }
}

function Read-PostgresSettings {
    param([string]$AppSettingsPath)
    if (-not (Test-Path $AppSettingsPath)) { return $null }
    try {
        $settings = Get-Content $AppSettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $values = @{}
        ([string]$settings.PostgresConnectionString).Split(";") | ForEach-Object {
            if ($_ -match "=") {
                $key, $value = $_.Split("=", 2)
                $values[$key.Trim().ToLowerInvariant()] = $value.Trim()
            }
        }
        return @{
            Host = if ($values.host) { $values.host } else { "127.0.0.1" }
            Port = if ($values.port) { $values.port } else { [string]$script:Config.PostgresPort }
            Database = if ($values.database) { $values.database } else { [string]$script:Config.DatabaseName }
            Username = if ($values.username) { $values.username } else { "postgres" }
            Password = $values.password
        }
    } catch {
        Write-InstallerLog "Ancienne configuration illisible : $($_.Exception.Message)"
        return $null
    }
}

function Write-NewAppSettings {
    param(
        [string]$InstallDirectory,
        [string]$Password,
        [string]$Username,
        [string]$LocalIp,
        [string]$AndroidBuildTools,
        [string]$JavaHome,
        [string]$Apktool,
        [bool]$ForceDatabaseSettings
    )
    $target = Join-Path $InstallDirectory "appsettings.Development.json"
    if (Test-Path $target) {
        Write-InstallerLog "Configuration existante récupérée et adaptée à l’adresse locale actuelle."
        if (-not $DryRun) {
            $settings = Get-Content $target -Raw -Encoding UTF8 | ConvertFrom-Json
            Copy-Item -LiteralPath $target -Destination ($target + ".installer-backup") -Force
            if ($ForceDatabaseSettings) {
                $settings.PostgresConnectionString = "Host=127.0.0.1;Port=$($script:Config.PostgresPort);Database=$($script:Config.DatabaseName);Username=$Username;Password=$Password"
            }
            $settings.PublicServerURL = "http://${LocalIp}:$($script:Config.PublicPort)"
            $settings | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $target -Encoding UTF8
        }
    } else {
        $example = Join-Path $InstallDirectory "appsettings.example.json"
        if (-not (Test-Path $example) -and -not $DryRun) { throw "appsettings.example.json est absent du projet téléchargé." }
        if (-not $DryRun) {
            $settings = Get-Content $example -Raw -Encoding UTF8 | ConvertFrom-Json
            $settings.PostgresConnectionString = "Host=127.0.0.1;Port=$($script:Config.PostgresPort);Database=$($script:Config.DatabaseName);Username=$Username;Password=$Password"
            $settings.PublicServerURL = "http://${LocalIp}:$($script:Config.PublicPort)"
            $settings | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $target -Encoding UTF8
        }
        Write-InstallerLog "Nouvelle configuration créée avec l’adresse $LocalIp."
    }
    $builderSettings = Join-Path $InstallDirectory "CUSTOM_APK_BUILDER\builder-settings.json"
    if (-not (Test-Path $builderSettings)) {
        $builder = [ordered]@{
            source_apk = ""
            server_ip = $LocalIp
            public_port = [string]$script:Config.PublicPort
            android_build_tools = $AndroidBuildTools
            java_home = $JavaHome
            apktool = $Apktool
            output_apk = ""
            key_password = "wibwob-custom-test"
            language = "fr"
        }
        if (-not $DryRun) {
            $builder | ConvertTo-Json | Set-Content -LiteralPath $builderSettings -Encoding UTF8
        }
    } elseif (-not $DryRun) {
        try {
            $builder = Get-Content $builderSettings -Raw -Encoding UTF8 | ConvertFrom-Json
            $builder.server_ip = $LocalIp
            $builder.public_port = [string]$script:Config.PublicPort
            if ($AndroidBuildTools) { $builder.android_build_tools = $AndroidBuildTools }
            if ($JavaHome) { $builder.java_home = $JavaHome }
            if ($Apktool) { $builder.apktool = $Apktool }
            $builder | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $builderSettings -Encoding UTF8
        } catch {
            Write-InstallerLog "Paramètres du constructeur conservés sans modification : $($_.Exception.Message)"
        }
    }
}

function Test-DatabaseExists {
    param([string]$PostgresBin, [hashtable]$Credentials)
    $psql = Join-Path $PostgresBin "psql.exe"
    if ($DryRun) { return $false }
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $psql
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $escapedDatabase = ([string]$Credentials.Database).Replace("'", "''")
    $arguments = @(
        "-h", $Credentials.Host, "-p", $Credentials.Port, "-U", $Credentials.Username,
        "-d", "postgres", "-w", "-t", "-A",
        "-c", "SELECT 1 FROM pg_database WHERE datname = '$escapedDatabase';"
    )
    $info.Arguments = (($arguments | ForEach-Object { ConvertTo-NativeArgument ([string]$_) }) -join " ")
    $info.EnvironmentVariables["PGPASSWORD"] = $Credentials.Password
    $process = [Diagnostics.Process]::Start($info)
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) {
        if ($stderr -match "password authentication failed|authentification par mot de passe.*échouée") {
            throw "[POSTGRES_PASSWORD_INVALID] Le mot de passe PostgreSQL est incorrect."
        }
        throw "Connexion PostgreSQL impossible. Vérifiez que le service PostgreSQL est démarré. $stderr"
    }
    return $stdout.Trim() -eq "1"
}

function Ensure-Database {
    param([string]$PostgresBin, [hashtable]$Credentials, [string]$InstallDirectory)
    if (Test-DatabaseExists -PostgresBin $PostgresBin -Credentials $Credentials) {
        Write-InstallerLog "La base $($Credentials.Database) existe : elle est conservée sans modification."
        return
    }
    Write-InstallerLog "Base absente : création et import initial."
    $environment = @{ PGPASSWORD = $Credentials.Password }
    Invoke-External -FilePath (Join-Path $PostgresBin "createdb.exe") -Environment $environment -Arguments @(
        "-h", $Credentials.Host, "-p", $Credentials.Port, "-U", $Credentials.Username,
        "-w", $Credentials.Database
    )
    $backup = Join-Path $InstallDirectory "WWR_BACKUP\backup_nomail.sql"
    if (-not (Test-Path $backup) -and -not $DryRun) { throw "Sauvegarde initiale introuvable : $backup" }
    Invoke-External -FilePath (Join-Path $PostgresBin "psql.exe") -Environment $environment -Arguments @(
        "-h", $Credentials.Host, "-p", $Credentials.Port, "-U", $Credentials.Username,
        "-d", $Credentials.Database, "-w", "-v", "ON_ERROR_STOP=1", "-f", $backup
    )
    Invoke-External -FilePath (Join-Path $PostgresBin "psql.exe") -Environment $environment -Arguments @(
        "-h", $Credentials.Host, "-p", $Credentials.Port, "-U", $Credentials.Username,
        "-d", $Credentials.Database, "-w", "-v", "ON_ERROR_STOP=1",
        "-c", 'CREATE TABLE IF NOT EXISTS public.mail (mail text PRIMARY KEY, "currentUdkey" text);'
    )
}

function Restore-DotNetPackages {
    param([string]$InstallDirectory, [string]$DotNetPath)
    if (-not $DotNetPath) { $DotNetPath = Get-DotNetPath }
    if (-not $DotNetPath -and $DryRun) { $DotNetPath = "dotnet.exe" }
    if (-not $DotNetPath) {
        throw "dotnet.exe est introuvable au moment de restaurer le projet. Réinstallez le SDK .NET 8 ou redémarrez Windows."
    }
    Invoke-External -FilePath $DotNetPath -WorkingDirectory $InstallDirectory -Arguments @(
        "restore", (Join-Path $InstallDirectory "Puniemu.csproj")
    )
}

function New-Shortcuts {
    param([string]$InstallDirectory)
    if ($DryRun) {
        Write-InstallerLog "SIMULATION : création des raccourcis Bureau."
        return
    }
    $desktop = [Environment]::GetFolderPath("Desktop")
    $shell = New-Object -ComObject WScript.Shell
    foreach ($shortcutDefinition in @(
        @{ Name = "WibWobPadaBoom.lnk"; Target = (Join-Path $InstallDirectory "LANCER_WIBWOB.bat"); Work = $InstallDirectory; Icon = (Join-Path $InstallDirectory "ADMIN_CLIENT\WibWobPadaBoom.ico") }
    )) {
        if (Test-Path $shortcutDefinition.Target) {
            $shortcut = $shell.CreateShortcut((Join-Path $desktop $shortcutDefinition.Name))
            $shortcut.TargetPath = $shortcutDefinition.Target
            $shortcut.WorkingDirectory = $shortcutDefinition.Work
            if (Test-Path -LiteralPath $shortcutDefinition.Icon -PathType Leaf) {
                $shortcut.IconLocation = "$($shortcutDefinition.Icon),0"
            }
            $shortcut.Save()
        }
    }
}

function Invoke-WibWobInstallation {
    param(
        [string]$InstallDirectory,
        [string]$OldDirectory,
        [string]$ProjectArchive,
        [string]$TypedPostgresPassword,
        [bool]$InstallApkTools
    )
    if (-not $DryRun -and -not (Test-Administrator)) {
        throw "L’installateur doit être exécuté en tant qu’administrateur."
    }
    $install = [IO.Path]::GetFullPath((Expand-ConfiguredPath $InstallDirectory))
    $temporary = Join-Path $env:TEMP ("WibWobSetup-" + [Guid]::NewGuid().ToString("N"))
    $migration = Join-Path $temporary "migration"
    $extracted = Join-Path $temporary "project"
    $newPassword = if ($TypedPostgresPassword) { $TypedPostgresPassword } else { New-LocalPassword }
    try {
        if (-not $DryRun) {
            New-Item -ItemType Directory -Path $temporary,$migration,$extracted -Force | Out-Null
        }
        Set-InstallerProgress 3 "Analyse de l’ancienne installation…"
        Export-LegacyState -OldDirectory $OldDirectory -MigrationDirectory $migration
        $oldSettings = if ($OldDirectory) { Read-PostgresSettings -AppSettingsPath (Join-Path $OldDirectory "appsettings.Development.json") } else { $null }

        Set-InstallerProgress 8 "Installation des prérequis du serveur…"
        $dotnetPath = Ensure-DotNet
        $postgres = Ensure-Postgres -NewPassword $newPassword

        $javaHome = ""
        $android = @{ BuildTools = "" }
        $apktool = ""
        if ($InstallApkTools) {
            Set-InstallerProgress 18 "Installation des outils APK…"
            $javaHome = Ensure-Java
            $android = Ensure-AndroidTools -JavaHome $javaHome -TemporaryDirectory $temporary
            $apktool = Ensure-Apktool -TemporaryDirectory $temporary
        }

        Set-InstallerProgress 35 "Lecture de l’archive du projet…"
        Assert-InstallationNotCancelled
        if ($null -ne $script:ProgressBar -and -not $DryRun) {
            $script:ProgressBar.Style = [Windows.Forms.ProgressBarStyle]::Marquee
            $script:ProgressBar.MarqueeAnimationSpeed = 25
        }
        $archive = Get-ProjectArchive -SelectedArchive $ProjectArchive -TemporaryDirectory $temporary
        Assert-InstallationNotCancelled
        if (-not $DryRun) {
            Set-InstallerProgress 45 "Décompression du ZIP en cours : cela peut prendre plusieurs minutes. L’interface reste utilisable."
            Expand-ProjectArchive -Archive $archive -Destination $extracted
            $sourceRoot = Find-ProjectRoot -ExtractedDirectory $extracted
        } else {
            $sourceRoot = Join-Path $extracted "WibWobReload"
        }

        if ($null -ne $script:ProgressBar) {
            $script:ProgressBar.Style = [Windows.Forms.ProgressBarStyle]::Continuous
        }
        Set-InstallerProgress 52 "Installation des fichiers du projet…"
        Copy-DirectoryContents -Source $sourceRoot -Destination $install
        Import-LegacyState -MigrationDirectory $migration -InstallDirectory $install

        $existingTargetSettings = Read-PostgresSettings -AppSettingsPath (Join-Path $install "appsettings.Development.json")
        $credentials = if ($postgres.InstalledNow) {
            @{
                Host = "127.0.0.1"
                Port = [string]$script:Config.PostgresPort
                Database = [string]$script:Config.DatabaseName
                Username = "postgres"
                Password = $newPassword
            }
        } elseif ($existingTargetSettings) {
            $existingTargetSettings
        } elseif ($oldSettings) {
            $oldSettings
        } else {
            @{
                Host = "127.0.0.1"
                Port = [string]$script:Config.PostgresPort
                Database = [string]$script:Config.DatabaseName
                Username = "postgres"
                Password = $TypedPostgresPassword
            }
        }
        if ($TypedPostgresPassword) { $credentials.Password = $TypedPostgresPassword }
        if ($DryRun -and -not $credentials.Password) {
            $credentials.Password = "dry-run-password"
        }
        if (-not $postgres.InstalledNow -and -not $credentials.Password) {
            throw "PostgreSQL existe déjà mais aucun mot de passe n’a été trouvé. Renseignez-le dans le champ Mot de passe PostgreSQL."
        }
        if (-not $credentials.Password) { $credentials.Password = $newPassword }

        Set-InstallerProgress 65 "Création de la configuration locale…"
        $localIp = Get-LocalIPv4
        Write-NewAppSettings -InstallDirectory $install -Password $credentials.Password -Username $credentials.Username `
            -LocalIp $localIp -AndroidBuildTools $android.BuildTools -JavaHome $javaHome -Apktool $apktool `
            -ForceDatabaseSettings ($postgres.InstalledNow -or [bool]$TypedPostgresPassword)

        Set-InstallerProgress 73 "Vérification de la base PostgreSQL…"
        Ensure-Database -PostgresBin $postgres.Bin -Credentials $credentials -InstallDirectory $install

        Set-InstallerProgress 90 "Restauration des dépendances .NET…"
        Restore-DotNetPackages -InstallDirectory $install -DotNetPath $dotnetPath
        New-Shortcuts -InstallDirectory $install

        Set-InstallerProgress 100 "Installation terminée."
        return @{
            InstallDirectory = $install
            Password = $credentials.Password
            PasswordWasGenerated = (-not $TypedPostgresPassword -and -not $oldSettings -and $postgres.InstalledNow)
        }
    } finally {
        if (-not $DryRun -and (Test-Path $temporary)) {
            try {
                [IO.Directory]::Delete($temporary, $true)
            } catch {
                # Cleanup must never turn a successful installation into a failure.
                Write-InstallerLog "Nettoyage temporaire reporte : $($_.Exception.Message)"
            }
        }
    }
}

function Invoke-SelfTest {
    $errors = [Collections.Generic.List[string]]::new()
    try {
        $ip = Get-LocalIPv4
        if (-not $ip) { $errors.Add("Détection IPv4 vide") }
    } catch { $errors.Add("IPv4 : $($_.Exception.Message)") }
    try {
        $password = New-LocalPassword
        if ($password.Length -lt 20) { $errors.Add("Mot de passe généré trop court") }
    } catch { $errors.Add("Mot de passe : $($_.Exception.Message)") }
    try {
        $expanded = Expand-ConfiguredPath $script:Config.DefaultInstallDirectory
        if ($expanded -match "%[^%]+%") { $errors.Add("Variable du dossier non développée") }
    } catch { $errors.Add("Chemin : $($_.Exception.Message)") }
    if ($errors.Count) {
        throw ("AUTO-TEST ÉCHOUÉ : " + ($errors -join " | "))
    }
    Write-Output "SELF_TEST_OK"
    Write-Output "CONFIG=$script:ConfigDescription"
    Write-Output "LOG=$script:LogFile"
}

if ($SelfTest) {
    Invoke-SelfTest
    return
}

if ($AutomatedDryRun) {
    $script:DryRun = $true
    $result = Invoke-WibWobInstallation `
        -InstallDirectory (Join-Path $env:TEMP "WibWob-Automated-DryRun") `
        -OldDirectory "" `
        -ProjectArchive "" `
        -TypedPostgresPassword "" `
        -InstallApkTools $false
    Write-Output "AUTOMATED_DRY_RUN_OK"
    Write-Output "TARGET=$($result.InstallDirectory)"
    return
}

if ($AutomatedMigrationDryRun) {
    $script:DryRun = $true
    $result = Invoke-WibWobInstallation `
        -InstallDirectory (Join-Path $env:TEMP "WibWob-Automated-Migration-DryRun") `
        -OldDirectory (Split-Path $script:ApplicationDirectory -Parent) `
        -ProjectArchive "" `
        -TypedPostgresPassword "" `
        -InstallApkTools $false
    Write-Output "AUTOMATED_MIGRATION_DRY_RUN_OK"
    Write-Output "TARGET=$($result.InstallDirectory)"
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$form = [Windows.Forms.Form]::new()
$form.Text = "WibWob Reload — Installation facile"
$form.Size = [Drawing.Size]::new(1000, 800)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = [Drawing.Size]::new(900, 740)

$title = [Windows.Forms.Label]::new()
$title.Text = "WibWob Reload — Installation facile"
$title.Font = [Drawing.Font]::new("Segoe UI", 17, [Drawing.FontStyle]::Bold)
$title.Location = [Drawing.Point]::new(24, 18)
$title.AutoSize = $true
$form.Controls.Add($title)

$description = [Windows.Forms.Label]::new()
$description.Text = "Installe le serveur, PostgreSQL et les outils nécessaires sans écraser une base existante."
$description.Location = [Drawing.Point]::new(28, 58)
$description.Size = [Drawing.Size]::new(750, 24)
$form.Controls.Add($description)

function Add-PathRow {
    param([string]$Label, [int]$Y, [string]$InitialValue, [bool]$AllowEmpty, [bool]$SelectZip = $false)
    $caption = [Windows.Forms.Label]::new()
    $caption.Text = $Label
    $caption.Location = [Drawing.Point]::new(28, $Y)
    $caption.Size = [Drawing.Size]::new(190, 24)
    $form.Controls.Add($caption)
    $box = [Windows.Forms.TextBox]::new()
    $box.Text = $InitialValue
    $box.Location = [Drawing.Point]::new(220, $Y - 3)
    $box.Size = [Drawing.Size]::new(650, 26)
    $box.Anchor = "Top,Left,Right"
    $form.Controls.Add($box)
    $button = [Windows.Forms.Button]::new()
    $button.Text = "Parcourir"
    $button.Location = [Drawing.Point]::new(880, $Y - 4)
    $button.Size = [Drawing.Size]::new(88, 28)
    $button.Anchor = "Top,Right"
    $button.Add_Click({
        if ($SelectZip) {
            $dialog = [Windows.Forms.OpenFileDialog]::new()
            $dialog.Title = "Sélectionner le ZIP WibWob Reload téléchargé depuis MEGA"
            $dialog.Filter = "Archives ZIP (*.zip)|*.zip"
            $dialog.CheckFileExists = $true
            $dialog.Multiselect = $false
            if ($box.Text) { $dialog.FileName = $box.Text }
            if ($dialog.ShowDialog($form) -eq "OK") { $box.Text = $dialog.FileName }
        } else {
            $dialog = [Windows.Forms.FolderBrowserDialog]::new()
            if ($box.Text) { $dialog.SelectedPath = $box.Text }
            if ($dialog.ShowDialog($form) -eq "OK") { $box.Text = $dialog.SelectedPath }
        }
        $dialog.Dispose()
    }.GetNewClosure())
    $form.Controls.Add($button)
    return $box
}

$installBox = Add-PathRow -Label "Dossier d’installation" -Y 105 `
    -InitialValue (Expand-ConfiguredPath $script:Config.DefaultInstallDirectory) -AllowEmpty $false
$oldBox = Add-PathRow -Label "Ancienne version (optionnel)" -Y 150 -InitialValue "" -AllowEmpty $true
$archiveBox = Add-PathRow -Label "ZIP téléchargé depuis MEGA" -Y 195 -InitialValue "" -AllowEmpty $false -SelectZip $true

$passwordLabel = [Windows.Forms.Label]::new()
$passwordLabel.Text = "Mot de passe PostgreSQL"
$passwordLabel.Location = [Drawing.Point]::new(28, 240)
$passwordLabel.Size = [Drawing.Size]::new(190, 24)
$form.Controls.Add($passwordLabel)

$passwordBox = [Windows.Forms.TextBox]::new()
$passwordBox.Location = [Drawing.Point]::new(220, 237)
$passwordBox.Size = [Drawing.Size]::new(300, 26)
$passwordBox.UseSystemPasswordChar = $true
$form.Controls.Add($passwordBox)

$passwordHint = [Windows.Forms.Label]::new()
$passwordHint.Text = "Vide = généré automatiquement. Si PostgreSQL existe déjà, indique son mot de passe."
$passwordHint.Location = [Drawing.Point]::new(530, 240)
$passwordHint.Size = [Drawing.Size]::new(430, 42)
$form.Controls.Add($passwordHint)


$dryRunCheck = [Windows.Forms.CheckBox]::new()
$dryRunCheck.Text = "Mode simulation (aucune modification)"
$dryRunCheck.Checked = [bool]$DryRun
$dryRunCheck.Location = [Drawing.Point]::new(670, 283)
$dryRunCheck.Size = [Drawing.Size]::new(290, 24)
$form.Controls.Add($dryRunCheck)

$script:StatusLabel = [Windows.Forms.Label]::new()
$script:StatusLabel.Text = "Prêt"
$script:StatusLabel.Location = [Drawing.Point]::new(28, 323)
$script:StatusLabel.Size = [Drawing.Size]::new(940, 24)
$script:StatusLabel.Anchor = "Top,Left,Right"
$form.Controls.Add($script:StatusLabel)

$script:ProgressBar = [Windows.Forms.ProgressBar]::new()
$script:ProgressBar.Location = [Drawing.Point]::new(28, 351)
$script:ProgressBar.Size = [Drawing.Size]::new(940, 22)
$script:ProgressBar.Anchor = "Top,Left,Right"
$form.Controls.Add($script:ProgressBar)

$script:LogControl = [Windows.Forms.RichTextBox]::new()
$script:LogControl.Location = [Drawing.Point]::new(28, 389)
$script:LogControl.Size = [Drawing.Size]::new(940, 285)
$script:LogControl.Anchor = "Top,Bottom,Left,Right"
$script:LogControl.ReadOnly = $true
$script:LogControl.Font = [Drawing.Font]::new("Cascadia Mono", 9)
$script:LogControl.BackColor = [Drawing.Color]::FromArgb(24, 24, 24)
$script:LogControl.ForeColor = [Drawing.Color]::Gainsboro
$form.Controls.Add($script:LogControl)

$installButton = [Windows.Forms.Button]::new()
$installButton.Text = "Installer"
$installButton.Location = [Drawing.Point]::new(748, 697)
$installButton.Anchor = "Bottom,Right"
$installButton.Size = [Drawing.Size]::new(105, 34)
$form.Controls.Add($installButton)

$closeButton = [Windows.Forms.Button]::new()
$closeButton.Text = "Fermer"
$closeButton.Location = [Drawing.Point]::new(863, 697)
$closeButton.Anchor = "Bottom,Right"
$closeButton.Size = [Drawing.Size]::new(105, 34)
$closeButton.Add_Click({
    if ($script:InstallationRunning) {
        $script:CancellationRequested = $true
        $closeButton.Enabled = $false
        $closeButton.Text = "Annulation…"
        $statusLabel.Text = "Annulation de l’installation…"
        if ($null -ne $script:ActiveProcess) {
            try { $script:ActiveProcess.Kill() } catch {}
        }
        return
    }
    $form.Close()
})
$form.Controls.Add($closeButton)

$logLabel = [Windows.Forms.Label]::new()
$logLabel.Text = "Journal : $script:LogFile"
$logLabel.Location = [Drawing.Point]::new(28, 705)
$logLabel.Size = [Drawing.Size]::new(700, 30)
$logLabel.Anchor = "Bottom,Left,Right"
$form.Controls.Add($logLabel)

function Test-PostgresPasswordError {
    param([System.Management.Automation.ErrorRecord]$ErrorRecord)
    return $ErrorRecord.Exception.Message -match "\[POSTGRES_PASSWORD_INVALID\]|password authentication failed|authentification par mot de passe.*échouée"
}

function Request-PostgresPassword {
    $dialog = [Windows.Forms.Form]::new()
    $dialog.Text = "Mot de passe PostgreSQL"
    $dialog.Size = [Drawing.Size]::new(485, 190)
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false

    $label = [Windows.Forms.Label]::new()
    $label.Text = "Le mot de passe PostgreSQL est incorrect.\r\nSaisis le bon mot de passe puis réessaie."
    $label.Location = [Drawing.Point]::new(18, 16)
    $label.Size = [Drawing.Size]::new(440, 42)
    $dialog.Controls.Add($label)

    $input = [Windows.Forms.TextBox]::new()
    $input.Location = [Drawing.Point]::new(18, 68)
    $input.Size = [Drawing.Size]::new(440, 26)
    $input.UseSystemPasswordChar = $true
    $dialog.Controls.Add($input)

    $ok = [Windows.Forms.Button]::new()
    $ok.Text = "Réessayer"
    $ok.DialogResult = [Windows.Forms.DialogResult]::OK
    $ok.Location = [Drawing.Point]::new(268, 108)
    $ok.Size = [Drawing.Size]::new(92, 30)
    $dialog.AcceptButton = $ok
    $dialog.Controls.Add($ok)

    $cancel = [Windows.Forms.Button]::new()
    $cancel.Text = "Annuler"
    $cancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    $cancel.Location = [Drawing.Point]::new(366, 108)
    $cancel.Size = [Drawing.Size]::new(92, 30)
    $dialog.CancelButton = $cancel
    $dialog.Controls.Add($cancel)

    $shown = $dialog.ShowDialog($form)
    $value = if ($shown -eq [Windows.Forms.DialogResult]::OK -and -not [string]::IsNullOrWhiteSpace($input.Text)) { $input.Text } else { $null }
    $dialog.Dispose()
    return $value
}

$installButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($installBox.Text)) {
        [Windows.Forms.MessageBox]::Show("Choisissez un dossier d’installation.", "WibWob Reload", "OK", "Warning")
        return
    }
    if (-not $dryRunCheck.Checked -and [string]::IsNullOrWhiteSpace($archiveBox.Text)) {
        [Windows.Forms.MessageBox]::Show(
            "Téléchargez le ZIP depuis la page MEGA ouverte dans votre navigateur, puis sélectionnez-le.",
            "WibWob Reload", "OK", "Warning"
        )
        return
    }
    $script:DryRun = $dryRunCheck.Checked
    $script:InstallationRunning = $true
    $script:CancellationRequested = $false
    $installButton.Enabled = $false
    $closeButton.Enabled = $true
    $closeButton.Text = "Annuler"
    try {
        $passwordAttempts = 0
        while ($true) {
            try {
                $result = Invoke-WibWobInstallation -InstallDirectory $installBox.Text -OldDirectory $oldBox.Text `
                    -ProjectArchive $archiveBox.Text `
                    -TypedPostgresPassword $passwordBox.Text -InstallApkTools $false
                break
            } catch {
                if (-not $script:DryRun -and $passwordAttempts -lt 3 -and (Test-PostgresPasswordError -ErrorRecord $_)) {
                    $newPassword = Request-PostgresPassword
                    if ($null -eq $newPassword) {
                        Set-InstallerProgress 0 "Installation annulée : mot de passe PostgreSQL requis."
                        return
                    }
                    $passwordBox.Text = $newPassword
                    $passwordAttempts++
                    Write-InstallerLog "Mot de passe PostgreSQL redemandé : nouvelle tentative."
                    continue
                }
                throw
            }
        }
        $message = "Installation terminée dans :`n$($result.InstallDirectory)"
        if ($result.PasswordWasGenerated) {
            $message += "`n`nUn mot de passe PostgreSQL sécurisé a été généré et enregistré dans appsettings.Development.json."
        }
        if ($script:DryRun) { $message = "Simulation terminée sans modification.`nConsultez le journal pour les opérations prévues." }
        [Windows.Forms.MessageBox]::Show($message, "WibWob Reload", "OK", "Information")
        if (-not $script:DryRun -and [bool]$script:Config.LaunchAdminWhenFinished) {
            $admin = Join-Path $result.InstallDirectory "ADMIN_CLIENT\WibWobPadaBoomAdminClient.exe"
            if (Test-Path $admin) { Start-Process -FilePath $admin -WorkingDirectory (Split-Path $admin -Parent) }
        }
    } catch {
        if ($_.Exception -is [OperationCanceledException] -or $script:CancellationRequested) {
            Set-InstallerProgress 0 "Installation annulée."
            Write-InstallerLog "Installation annulée par l’utilisateur."
        } else {
            Set-InstallerProgress 0 "Échec de l’installation."
            Write-InstallerLog $_.Exception.ToString()
            [Windows.Forms.MessageBox]::Show(
                "$($_.Exception.Message)`n`nJournal : $script:LogFile",
                "Installation impossible", "OK", "Error"
            )
        }
    } finally {
        $script:InstallationRunning = $false
        $script:ActiveProcess = $null
        if ($null -ne $script:ProgressBar) {
            $script:ProgressBar.Style = [Windows.Forms.ProgressBarStyle]::Continuous
        }
        $installButton.Enabled = $true
        $closeButton.Enabled = $true
        $closeButton.Text = "Fermer"
    }
})

Write-InstallerLog "Installateur chargé. Configuration : $script:ConfigDescription"
if (-not (Test-Administrator)) {
    Write-InstallerLog "Attention : l’installation réelle demandera des droits administrateur."
}
$form.Add_Shown({
    $megaUrl = [string]$script:Config.ProjectMegaUrl
    if ($megaUrl -match "^https://mega\.nz/") {
        Write-InstallerLog "Ouverture de la page MEGA pour télécharger le ZIP du projet."
        try {
            Start-Process -FilePath $megaUrl
        } catch {
            Write-InstallerLog "Impossible d’ouvrir automatiquement MEGA : $($_.Exception.Message)"
        }
    }
})
[void]$form.ShowDialog()
