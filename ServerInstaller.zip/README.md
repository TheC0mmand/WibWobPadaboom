# Installateur facile WibWob Reload

L’installateur prépare une nouvelle installation Windows ou migre une ancienne version.

## Utilisation

1. Lancez `WibWobInstaller_1.1.2.exe`.
2. La page MEGA du projet s’ouvre automatiquement dans le navigateur.
3. Téléchargez le ZIP sans le décompresser.
4. Dans l’installateur, cliquez sur **Parcourir** à côté de **ZIP téléchargé depuis MEGA** et sélectionnez ce fichier.
5. Choisissez le dossier d’installation, éventuellement l’ancienne version, puis cliquez sur **Installer**.

L’installateur n’utilise plus MEGAcmd et ne télécharge pas lui-même le projet.

## Fonctions

- installation de .NET SDK 8 et PostgreSQL si nécessaire ;
- installation facultative de Java 21, Android Build-Tools et APKTool ;
- conservation d’une base PostgreSQL `wibwob` existante ;
- migration de la configuration, des sauvegardes Admin, des clés APK et des paramètres du Builder ;
- génération de la configuration avec l’adresse IPv4 locale ;
- restauration des dépendances .NET et création des raccourcis.

Une base existante n’est jamais supprimée et son mot de passe n’est jamais changé automatiquement.

## Construction

```powershell
.\Build-Installer.ps1 -OutputDirectory .\release -Version 1.1.2
```

Le ZIP produit contient le lanceur C# ainsi que le script PowerShell visible. Le format PS2EXE n’est pas utilisé dans la release normale.

## Mise a jour automatique

Au lancement, l'installateur lit `installer.auto.json` sur la branche GitHub `Auto-Update`. Si une version superieure est publiee, il telecharge l'EXE, verifie son SHA-256 puis le lance. Sans connexion ou si GitHub est indisponible, il continue normalement.

## Tests

```powershell
powershell -ExecutionPolicy Bypass -File .\code.ps1 -SelfTest
powershell -ExecutionPolicy Bypass -File .\code.ps1 -AutomatedDryRun
powershell -ExecutionPolicy Bypass -File .\code.ps1 -AutomatedMigrationDryRun
```
