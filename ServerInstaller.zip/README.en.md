# WibWob Reload Easy Installer

The installer prepares a new Windows installation or migrates an older version.

## Usage

1. Run `WibWobInstaller_1.1.2.exe`.
2. The project’s MEGA page opens automatically in the browser.
3. Download the ZIP without extracting it.
4. In the installer, use **Browse** next to the downloaded ZIP field and select it.
5. Choose the destination, optionally select an older installation, and start the installation.

The installer no longer uses MEGAcmd and does not download the project itself.

## Features

- installs .NET SDK 8 and PostgreSQL when required;
- optionally installs Java 21, Android Build-Tools, and APKTool;
- preserves an existing `wibwob` PostgreSQL database;
- migrates configuration, Admin backups, APK keys, and Builder settings;
- creates the local configuration and restores .NET dependencies;
- creates desktop shortcuts.

An existing database is never deleted and its password is never changed automatically.

## Build

```powershell
.\Build-Installer.ps1 -OutputDirectory .\release -Version 1.1.2
```

The resulting ZIP contains the C# launcher and the readable PowerShell source. Normal releases do not use PS2EXE.

## Automatic updates

At startup, the installer reads `installer.auto.json` from the GitHub `Auto-Update` branch. When a newer version is published, it downloads the EXE, verifies its SHA-256 hash, then launches it. If GitHub is unavailable, the current installer continues normally.

## Tests

```powershell
powershell -ExecutionPolicy Bypass -File .\code.ps1 -SelfTest
powershell -ExecutionPolicy Bypass -File .\code.ps1 -AutomatedDryRun
powershell -ExecutionPolicy Bypass -File .\code.ps1 -AutomatedMigrationDryRun
```
